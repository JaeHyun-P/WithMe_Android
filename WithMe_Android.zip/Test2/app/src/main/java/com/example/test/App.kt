package com.example.test

import android.app.Application

class App : Application() { //MainActivity.kt의 SharedPreferences(정보 저장 부분)를 정의하는 코드.

    companion object{
        lateinit var prefs : SharedPreferences
        lateinit var prefss : SharedPreferences
        lateinit var prefsss : SharedPreferences
    }

    override fun onCreate() {
        prefs = SharedPreferences(applicationContext)
        prefss = SharedPreferences(applicationContext)
        prefsss = SharedPreferences(applicationContext)
        super.onCreate()
    }
}