package com.example.test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputName.setText(App.prefs.myEditText) //어플 실행 시 inputName 칸에 저장했던 값을 출력해준다.
        inputHeight.setText(App.prefss.myEditHeight)//어플 실행 시 inputHeight 칸에 저장했던 값을 출력해준다.
        inputWeight.setText(App.prefsss.myEditWeight)//어플 실행 시 inputWeight 칸에 저장했던 값을 출력해준다.

        SaveButton.setOnClickListener{
            App.prefs.myEditText = inputName.text.toString()//저장 버튼을 누르면 inputName 에 적힌 값을 저장한다.
            App.prefss.myEditHeight = inputHeight.text.toString()//저장 버튼을 누르면 inputHeight 에 적힌 값을 저장한다.
            App.prefsss.myEditWeight = inputWeight.text.toString()//저장 버튼을 누르면 inputWeight 에 적힌 값을 저장한다.
        }

        val secondIntent = Intent(this, ChatActivity :: class.java)//화면 하단의 채팅 버튼을 누르면 채팅 탭으로 이동한다.

        ChatButton.setOnClickListener{
            startActivity(secondIntent)
        }
        val thirdIntent = Intent(this, SearchActivity :: class.java)//화면 하단의 열량 버튼을 누르면 열량 정보 탭으로 이동한다.

        KalButton.setOnClickListener {
            startActivity(thirdIntent)
        }
        val quadIntent = Intent(this, TipActivity :: class.java)//화면 하단의 Tip 버튼을 누르면 Tip 탭으로 이동한다.

        TipButton.setOnClickListener {
            startActivity(quadIntent)
        }
    }
    private var backPressedTime : Long = 0//뒤로가기 버튼을 누르면 어플이 종료되도록 하는 코드
    override fun onBackPressed() {
        Log.d("TAG", "뒤로가기")

        if (System.currentTimeMillis() - backPressedTime < 2000) {
            finish()
            return
        }
        backPressedTime = System.currentTimeMillis()
        finishAffinity()
    }
}
