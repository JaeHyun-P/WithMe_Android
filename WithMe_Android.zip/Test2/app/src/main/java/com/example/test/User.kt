package com.example.test

class User (val profile : Int, val name:String, val kal :String)
/*
    클래스 모델 객체
 */