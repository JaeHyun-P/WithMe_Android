package com.example.test

import android.content.Context
import android.content.SharedPreferences

class SharedPreferences(context: Context) {

    private val prefsFilename = "prefs"
    private val prefsKeyEdit = "myEditText"
    private val prefs: SharedPreferences = context.getSharedPreferences(prefsFilename, 0)

    private val prefssFilename = "prefss"
    private val prefssKeyEdit = "myEditHeight"
    private val prefss: SharedPreferences = context.getSharedPreferences(prefssFilename, 0)

    private val prefsssFilename = "prefsss"
    private val prefsssKeyEdit = "myEditWeight"
    private val prefsss: SharedPreferences = context.getSharedPreferences(prefsssFilename, 0)

    var myEditText:String?
        get() = prefs.getString(prefsKeyEdit, "")
        set(value) = prefs.edit().putString(prefsKeyEdit, value).apply()

    var myEditHeight:String?
        get() = prefss.getString(prefssKeyEdit, "")
        set(value) = prefss.edit().putString(prefssKeyEdit, value).apply()

    var myEditWeight:String?
        get() = prefsss.getString(prefsssKeyEdit, "")
        set(value) = prefsss.edit().putString(prefsssKeyEdit, value).apply()
}