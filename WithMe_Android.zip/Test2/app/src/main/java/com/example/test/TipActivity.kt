package com.example.test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_tip.*


class TipActivity : AppCompatActivity() {

    var SportsList = arrayListOf<Sports>( //미리 설정된 리스트에서 종목과 소모 칼로리를 표현하는 코드.
        Sports(R.drawable.prof, "윗몸 일으키기", "1회 당 10kal"),
        Sports(R.drawable.runge, "런지", "1회 당 6kal"),
        Sports(R.drawable.running, "달리기", "1시간 당 557kal(시속 10km 기준)"),
        Sports(R.drawable.swim, "수영", "1시간 당 528kal"),
        Sports(R.drawable.spinning, "스피닝", "1시간 당 588kal"),
        Sports(R.drawable.aerobic, "에어로빅", "1시간 당 683~1074kal"),
        Sports(R.drawable.badminton, "배드민턴", "1시간 당 368kal"),
        Sports(R.drawable.jumping, "줄넘기", "1000개 당 150kal(체중 55kg 기준)"),
        Sports(R.drawable.fencing, "펜싱", "1시간 당 660kal"),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tip)

        val Adapter = SportsAdapter(this, SportsList) //종목에 대한 어댑터를 선언 및 호출하는 코드
        listview.adapter=Adapter

        val secondIntent = Intent(this, ChatActivity :: class.java) //화면 하단의 챗 봇 버튼을 누르면 챗 봇 탭으로 이동한다.

        ChatButton.setOnClickListener{
            startActivity(secondIntent)
        }
        val thirdIntent = Intent(this, SearchActivity :: class.java) //화면 하단의 열량 버튼을 누르면 열량 정보 탭으로 이동한다.

        KalButton.setOnClickListener {
            startActivity(thirdIntent)
        }
        val quadIntent = Intent(this, MainActivity :: class.java) //화면 하단의 프로필 버튼을 누르면 프로필 탭으로 이동한다.

        InformationButton.setOnClickListener {
            startActivity(quadIntent)
        }
    }
    private var backPressedTime : Long = 0 //뒤로가기 버튼을 누르면 어플이 종료되도록 하는 코드
    override fun onBackPressed() {
        Log.d("TAG", "뒤로가기")

        if(System.currentTimeMillis() - backPressedTime < 2000){
            finish()
            return
        }
        backPressedTime = System.currentTimeMillis()
        finishAffinity()
    }
}
