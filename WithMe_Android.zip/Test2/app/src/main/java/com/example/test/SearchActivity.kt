package com.example.test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_search.*

class SearchActivity : AppCompatActivity() {

    var UserList = arrayListOf<User>( //미리 설정된 리스트 형식에서 메뉴와 열량 표현하는 코드.
        User(R.drawable.americano, "스타벅스 아메리카노","10kal"),
        User(R.drawable.signaturehotchoco, "스타벅스 시그니처 핫 초코","500kal"),
        User(R.drawable.macchiato, "스타벅스 마끼아또","190kal"),
        User(R.drawable.jjajangmyeon, "짜장면", "864kal"),
        User(R.drawable.jjambbong, "짬뽕", "788kal"),
        User(R.drawable.boodae, "부대찌개", "712kal"),
        User(R.drawable.chocosora, "파리바게트 초코소라빵", "160kal"),
        User(R.drawable.chococreamamondball, "파리바게트 초코크림 아몬드볼", "320kal"),
        User(R.drawable.cinnamonroll, "파리바게트 클래식 시나몬롤", "300kal"),
        User(R.drawable.neoguri, "농심 너구리", "490kal"),
        User(R.drawable.sinramyeon, "농심 신라면", "500kal"),
        User(R.drawable.welchs, "웰치스", "184kal"),
        User(R.drawable.caprisun, "카프리썬", "60kal")
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        val Adapter = UserAdapter(this, UserList)//열량 정보에 대한 어댑터를 선언 및 호출하는 코드
        listView.adapter = Adapter


        val secondIntent = Intent(this, ChatActivity :: class.java)//화면 하단의 채팅 버튼을 누르면 채팅 탭으로 이동한다.

        ChatButton.setOnClickListener{
            startActivity(secondIntent)
        }
        val thirdIntent = Intent(this, TipActivity :: class.java)//화면 하단의 Tip 버튼을 누르면 Tip 탭으로 이동한다.

        TipButton.setOnClickListener {
            startActivity(thirdIntent)
        }
        val quadIntent = Intent(this, MainActivity :: class.java)//화면 하단의 프로필 버튼을 누르면 프로필 탭으로 이동한다.

        InformationButton.setOnClickListener {
            startActivity(quadIntent)
        }
    }
    private var backPressedTime : Long = 0//뒤로가기 버튼을 누르면 어플이 종료되도록 하는 코드
    override fun onBackPressed() {
        Log.d("TAG", "뒤로가기")

        if(System.currentTimeMillis() - backPressedTime < 2000){
            finish()
            return
        }
        backPressedTime = System.currentTimeMillis()
        finishAffinity()
    }
}