package com.example.test

import android.content.Context
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class SportsAdapter (val context:Context, val SportsList: ArrayList<Sports>) : BaseAdapter()

{
    override fun getCount(): Int {
        return SportsList.size

    }

    override fun getItem(position: Int): Any {
        return SportsList[position]

    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view:View = LayoutInflater.from(context).inflate(R.layout.list_event_sports, null)

        val profile = view.findViewById<ImageView>(R.id.iv_prof)
        val event = view.findViewById<TextView>(R.id.tv_event)
        val explanation = view.findViewById<TextView>(R.id.tv_explanation)

        val sports = SportsList[position]

        profile.setImageResource(sports.profile)
        event.text=sports.event
        explanation.text=sports.explanation

        return view
    }
}