package com.example.test

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import kotlinx.android.synthetic.main.activity_chat.*



class ChatActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        webView.settings.javaScriptEnabled = true // 자바 스크립트 허용
        /* 웹 뷰에서 새 창이 뜨지 않도록 방지하는 구문 */
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.loadUrl("https://console.dialogflow.com/api-client/demo/embedded/6ddef748-0923-4053-a84f-9d9ac69b0bcf")//링크 주소를 load한다.



        val secondIntent = Intent(this, SearchActivity :: class.java)//화면 하단의 열량 버튼을 누르면 열량 정보 탭으로 이동한다.

        KalButton.setOnClickListener{
            startActivity(secondIntent)
        }
        val thirdIntent = Intent(this, TipActivity :: class.java)//화면 하단의 Tip 버튼을 누르면 Tip 탭으로 이동한다.

        TipButton.setOnClickListener {
            startActivity(thirdIntent)
        }
        val quadIntent = Intent(this, MainActivity :: class.java)//화면 하단의 프로필 버튼을 누르면 프로필 탭으로 이동한다.

        InformationButton.setOnClickListener {
            startActivity(quadIntent)
        }
    }
    private var backPressedTime : Long = 0//뒤로가기 버튼을 누르면 어플이 종료되도록 하는 코드
    override fun onBackPressed() {
        Log.d("TAG", "뒤로가기")

        if(System.currentTimeMillis() - backPressedTime < 2000){
            finish()
            return
        }
        backPressedTime = System.currentTimeMillis()
        finishAffinity()
    }

}