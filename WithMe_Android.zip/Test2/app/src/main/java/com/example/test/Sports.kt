package com.example.test

class Sports (val profile: Int, val event:String, val explanation:String)
